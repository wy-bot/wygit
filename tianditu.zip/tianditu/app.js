import 'style-loader!css-loader!ol/ol.css';
import {Map,View} from 'ol';
import TileLayer from 'ol/layer/Tile';
import XYZ from 'ol/source/XYZ';
import WMTS from 'ol/source/WMTS'
import WMTSTileGrid from 'ol/tilegrid/WMTS';
import {fromLonLat, get as getProjection, Projection} from 'ol/proj';
import {getTopLeft,getWidth} from 'ol/extent';

//xyz加载天地图
// const map_xyz = new Map({
//     target: "map",
//     layers:[
//         new TileLayer({
//             source: new XYZ({
//                 url: "http://t0.tianditu.com/DataServer?T=vec_w&x={x}&y={y}&l={z}&tk=1b5c70b0b006efdd020b4e374c73b1b9"
//             })
//         }),
//         new TileLayer({
//             source: new XYZ({
//                 url: "http://t0.tianditu.com/DataServer?T=cva_w&x={x}&y={y}&l={z}&tk=1b5c70b0b006efdd020b4e374c73b1b9"
//             })
//         })
//     ],
//     view: new View({
//         center: [0,0],
//         zoom: 2
//     })
// })

//wmts加载天地图
const projection = getProjection("EPSG:4326");
const projectionExtent = projection.getExtent();
const size = getWidth(projectionExtent)/256;
const resolutions = new Array(19);
const matrixIds = new Array(19);
for (let z=0;z<=19;++z){
    resolutions[z] = size / Math.pow(2,z);
    matrixIds[z] = z
}

const map_wmts = new Map({
    target: "map",
    layers:[
        new TileLayer({
            opacity: 0.7,
            source: new WMTS({
                attributions:
                  'Tiles © <a href="https://mrdata.usgs.gov/geology/state/"' +
                  ' target="_blank">USGS</a>',
                url: "http://t0.tianditu.gov.cn/vec_w/wmts?tk=1b5c70b0b006efdd020b4e374c73b1b9",
                layer: "vec",
                matrixSet: "w",
                format: "tiles",
                projection: projection,
                tileGrid: new WMTSTileGrid({
                    origin: getTopLeft(projectionExtent),
                    resolutions: resolutions,
                    matrixIds: matrixIds
                }),
                style: "default",
                wrapX: true
            })
        })
    ],
    view: new View({
        projection: projection,
        center: fromLonLat([110, 0]),
        zoom: 5
    })
})

